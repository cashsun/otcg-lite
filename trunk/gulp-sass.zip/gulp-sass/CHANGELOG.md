### 1.3.3

* updated to node-sass 2.0 (final)
* should now work with node 0.12 and io.js

### 1.3.2

* fixed errLogToConsole

### 1.3.1

* bug fix

## Version 1.3.0

* Supports node-sass 2.0 (thanks laurelnaiad!)
